<?php

/*
─═ঊঈঊঈ═─╮ 
کانال رباتسازی آیرو_بوتساز 
انواع سورس 
رایگان و دیباگ 
ادرس کانال 
https://t.me/IRO_BOTSAZ
─═ঊঈঊঈ═─╯
*/
ob_start();
error_reporting(0);
define('API_KEY','A1');   //// توکن
// include
include("getpersian.php");
//-----------------------------------------------------------------------------------------
//فانکشن jijibot :
function jijibot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//-----------------------------------------------------------------------------------------
//متغیر ها :
// msg
$Dev = array("A2","A2","A2"); // ایدی عددد ادمین
$usernamebot = "A3";   //////ایدی ربات بدون @
$channel = "A4";   ////ایدی کانال بدون @
$web = "A5"; // محل قرار گیری سورس
$token = "A1";
//-----------------------------------------------------------------------------------------------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$textmassage = $message->text;
$messageid = $update->callback_query->message->message_id;
$tc = $update->message->chat->type;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$data = $update->callback_query->data;
$membercall = $update->callback_query->id;
// ========================================================================
$forchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@".$channel."&user_id=".$from_id));
$tch = $forchannel->result->status;
//====================================================================
//فانکشن ها :
function RandomString()
{
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randstring = '';
    for ($i = 0; $i < 9; $i++) {
        $randstring .= $characters[rand(0, strlen($characters))];
    }
    return $randstring;
}
//=================================================================================================
@$juser = json_decode(file_get_contents("data/$from_id.json"),true);
@$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
@$packlist = json_decode(file_get_contents("data/packlist.json"),true);
//==================================================================
if($textmassage=="/start"){	
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سلام $first_name 👋🏻

به ربات استیکر ساز تلگرام خوش امدید 🌹

به وسیله این ربات میتونید استیکر های مختلف برای اسم خودتون بسازید و لذت ببرید  😝 

🌟 برای شروع یک نوع استیکر رو انتخاب کن",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🤴🏻 استیکر پسرونه"],['text'=>"👸🏻 استیکر دخترونه"]
                ],
												                 [
                ['text'=>"🤵🏻 استیکر دونفره 👰🏻"],['text'=>"😃 استیکر متفرقه"]
                ],
															                 [
                ['text'=>"👤 حساب کاربری"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
if(!file_exists("data/$from_id.json")){
$juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["userfild"]["cancreat"]="1";
$juser["userfild"]["member"]="0";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
elseif(strpos($textmassage , '/start ') !== false  ) {
$start = str_replace("/start ","",$textmassage);
if(file_exists("data/$from_id.json")){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سلام $first_name 👋🏻

به ربات استیکر ساز تلگرام خوش امدید 🌹

به وسیله این ربات میتونید استیکر های مختلف برای اسم خودتون بسازید و لذت ببرید  😝 

🌟 برای شروع یک نوع استیکر رو انتخاب کن",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🤴🏻 استیکر پسرونه"],['text'=>"👸🏻 استیکر دخترونه"]
                ],
												                 [
                ['text'=>"🤵🏻 استیکر دونفره 👰🏻"],['text'=>"😃 استیکر متفرقه"]
                ],
															                 [
                ['text'=>"👤 حساب کاربری"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
else 
{
$inuser = json_decode(file_get_contents("data/$start.json"),true);
$member = $inuser["userfild"]["member"];
$cancreat = $inuser["userfild"]["cancreat"];
$plusmember = $member + 1;
$pluscreat = $cancreat + 1;
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سلام $first_name 👋🏻

به ربات استیکر ساز تلگرام خوش امدید 🌹

به وسیله این ربات میتونید استیکر های مختلف برای اسم خودتون بسازید و لذت ببرید  😝 

🌟 برای شروع یک نوع استیکر رو انتخاب کن",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🤴🏻 استیکر پسرونه"],['text'=>"👸🏻 استیکر دخترونه"]
                ],
												                 [
                ['text'=>"🤵🏻 استیکر دونفره 👰🏻"],['text'=>"😃 استیکر متفرقه"]
                ],
															                 [
                ['text'=>"👤 حساب کاربری"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
jijibot('sendmessage',[
	'chat_id'=>$start,
	'text'=>"🌟 کاربر [$first_name](tg://user?id=$from_id) با استفاده از لینک دعوت شما وارد ربات شده
📍 یک فرصت ساخت استیکر و یک زیر مجموعه برای شما اضافه شد

❄️تعداد فرصت های ساخت استیکر شما : $pluscreat	
👥تعداد زیر مجموعه ها : $plusmember",
			 'parse_mode'=>"MarkDown",
	  	]);
$inuser["userfild"]["member"]="$plusmember";
$inuser["userfild"]["cancreat"]="$pluscreat";
$inuser = json_encode($inuser,true);
file_put_contents("data/$start.json",$inuser);
$juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["userfild"]["member"]="0";
$juser["userfild"]["cancreat"]="1";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
elseif($textmassage=="🔙 برگشت"){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 به منوی اصلی ربات خوش امدید 
	
🌟 از دکمه های زیر استفاده کنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🤴🏻 استیکر پسرونه"],['text'=>"👸🏻 استیکر دخترونه"]
                ],
												                 [
                ['text'=>"🤵🏻 استیکر دونفره 👰🏻"],['text'=>"😃 استیکر متفرقه"]
                ],
															                 [
                ['text'=>"👤 حساب کاربری"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$juser["userfild"]["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
elseif($textmassage=="👤 حساب کاربری"){
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
$member = $juser["userfild"]["member"];
$cancreat = $juser["userfild"]["cancreat"];
if($member >= 5){
		jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎫 حساب کاربری شما در ربات ساخت استیکر :
❄️ نوع حساب : ویژه
👥 تعداد زیر مجموعه : $member
🌟تعداد فرصت ساخت استیکر : $cancreat
📍ایدی شما : $from_id",
	  	]);
}
else
{
		jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎫 حساب کاربری شما در ربات ساخت استیکر :
	
❄️ نوع حساب : عادی
👥 تعداد زیر مجموعه : $member
🌟تعداد فرصت ساخت استیکر : $cancreat
📍ایدی شما : $from_id

🏵 با ویژه کردن حساب خود میتوانید از تمام رنگ ها برای متن استفاده کنید
❄️ کاربران ویژه علاوه بر امکان استفاده از تمام رنگ ها میتوانند از پک های دو اسمی نیز استفاده کنند",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"❄️ حساب ویژه",'callback_data'=>'link']
	],
              ]
        ])
	  	]);
}
}
else
{
 jijibot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"🔘 برای استفاده از ربات ساخت استیکر ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"📍 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($textmassage=="🤴🏻 استیکر پسرونه"){
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🌟 نام پک : پسر عاشق
📍 تعداد استیکر : 15 عدد 
🎈 شماره پک : 1 از 5
[‌‌]($web/replica/mohammad.jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"⏭ بعدی",'callback_data'=>'nextboy']
	],
              ]
        ])
    		]);
$juser["userfild"]["get"]="0";
$juser["userfild"]["type"]="boy";
$juser["userfild"]["pack"]="mohammad";
$juser["userfild"]["packname"]="پسر عاشق";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
 jijibot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"🔘 برای استفاده از ربات ساخت استیکر ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"📍 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($textmassage=="😃 استیکر متفرقه"){
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🌟 نام پک : مینیون ها
📍 تعداد استیکر : 14 عدد
🎈 شماره پک : 1 از 5
[‌‌]($web/replica/menion.jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"⏭ بعدی",'callback_data'=>'nextother']
	],
              ]
        ])
    		]);
$juser["userfild"]["get"]="0";
$juser["userfild"]["type"]="other";
$juser["userfild"]["pack"]="menion";
$juser["userfild"]["packname"]="مینیون ها";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
 jijibot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"🔘 برای استفاده از ربات ساخت استیکر ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"📍 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($textmassage=="👸🏻 استیکر دخترونه"){
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🌟 نام پک : دختر عاشق
📍 تعداد استیکر : 19 عدد
🎈 شماره پک : 1 از 5
[‌‌]($web/replica/sanaz.jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"⏭ بعدی",'callback_data'=>'nextgirl']
	],
              ]
        ])
    		]);
$juser["userfild"]["get"]="0";
$juser["userfild"]["type"]="girl";
$juser["userfild"]["pack"]="sanaz";
$juser["userfild"]["packname"]="دختر عاشق";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
 jijibot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"🔘 برای استفاده از ربات ساخت استیکر ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"📍 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($textmassage=="🤵🏻 استیکر دونفره 👰🏻"){
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🌟 نام پک : عشق
📍 تعداد استیکر : 10 عدد
🎈 شماره پک : 1 از 3
[‌‌]($web/replica/love.jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'selectvip']
	],
			[
	['text'=>"⏭ بعدی",'callback_data'=>'nextgb']
	],
              ]
        ])
    		]);
$juser["userfild"]["get"]="0";
$juser["userfild"]["type"]="boyandgirl";
$juser["userfild"]["pack"]="love";
$juser["userfild"]["packname"]="عشق";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
 jijibot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"🔘 برای استفاده از ربات ساخت استیکر ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"📍 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif(in_array($textmassage,array("🎨 سفید","🎨 مشکی","🎨 سبز","🎨 ابی","🎨 زرد","🎨 قرمز","🎨 خاکستری","🎨 نقره ای","🎨 بنفش","🎨 قهوه ای"))){
$cancreat = $juser["userfild"]["cancreat"];
if($cancreat > 0){
$type = $juser["userfild"]["type"];
$pack = $juser["userfild"]["pack"];
$gettext = $juser["userfild"]["name"];
$packanme = $juser["userfild"]["packname"];
$repalcecolor = str_replace(["🎨 سفید","🎨 مشکی","🎨 سبز","🎨 ابی","🎨 زرد","🎨 قرمز","🎨 خاکستری","🎨 نقره ای","🎨 بنفش","🎨 قهوه ای"],["whitepen","blackpen","greenpen","bluepen","greypen","redpen","greypen","silverpen","navypen","maroonpen"],$textmassage);
if($packlist["$pack"]["$gettext"]["$repalcecolor"] != true){
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"🌟 پک استیکر شما در حال ساخت است لطفا منتطر بمانید ...
		
📍 این عملیات ممکن است تا 3 دقیقه طول بکشد",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🤴🏻 استیکر پسرونه"],['text'=>"👸🏻 استیکر دخترونه"]
                ],
												                 [
                ['text'=>"🤵🏻 استیکر دونفره 👰🏻"],['text'=>"😃 استیکر متفرقه"]
                ],
															                 [
                ['text'=>"👤 حساب کاربری"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$ITCKRIST = "font/ITCKRIST.TTF";
$ANegaarBold = "font/ANegaarBold.ttf";
$NPIFarnazIranic = "font/NPIFarnazIranic.ttf";
$packanme = $juser["userfild"]["packname"];
$get = RandomString();
$simon = array("خوابش میاد","عصبانیه","عاشقته","شرمندست","ترسیده","میکشتت","تو فکره","شیطونه","دوست داره","نگرانه","گریه میکنه","میخنده","خوش حاله");
$bob = array("میخنده","ترسیده","ناراحته","خیلی خوشحاله","خوشحاله","عاشقته","دوست داره","به فکر تو","خوش حاله","عاشقته");
$boss = array("گریه میکنه","مُرد","عصبانیه","خوابش میاد","حرف میزنه","ناراحته","راحته","ذوق کرده","نمیدونه","مطمعنه");
$mohammad = array("خیلی خورده","هدیه گرفته","خوابش برد","منتظره","تیپ زده","گریه میکنه","دیوونه شد","خجالت کشید","به فکر توعه","عصبانیه","تعجب کرده","ورزش میکنه","رفته حموم","عاشقته","خسته شده");
$oscar = array("دلش میخواد","شجاعه","دیوونه شد","ناراحته","ضایع شد","سلام میکنه","خوشش اومد","گشنشه","تعجب کرد","خسته شد");
$mahsa = array("خیلی خندید","دوست داره","دیوونه شد","جارو میزنه","ناراحته","دلش میخواد","برف دوس","خیلی ناراحته","نقاش شده","حالش بده","پیر شده","نگران شده","خوشش اومد");
$zoot = array("موفق شد","خوشش اومد","ناراحته","تعجب کرد","نمیدونه","ترسیده","سلام میکنه","خوش حاله","مُرد","عصبانیه","نگران شده","سرگرمه","تعجب کرد","دوست داره");
$sanaz = array("خوش حاله","ناراحته","رقصش گرفته","خوابش برد","خوابش میاد","رفته حموم","گشنشه","باهات قهره","آرایش میکنه","دیوونه شد","خسته شده","عصبانیه","به فکر تو","بوس فرستاده","منتظره","دلش شکسته","رفته خرید","خیلی گشنشه","عصبانیه");
$elsa = array("بوس میفرسته","نگرانه","بازیش گرفته","تعجب کرده","ناراحته","خوشش اومد","دیوونه شد","خوشگل کرده","تیپ زده","عصبانی شد");
$anges = array("دلش میخواد","عصبانیه","قهره","نگرانه","ارزو میکنه","خسته شده","ناراحته","خیلی عصبانیه","خوابش برد","اومد","دیوونه شد");
$rani = array("گشنشه","دیونه شد","خوابش میاد","عاشقته","تعجب کرد","خوش حاله","تو قکره","خوشش اومده","گریه داره","میخنده","ناراحته");
$menion = array("سلام میکنه","خیلی نازه","میکشتت","داغون شد","سلفی میگیره","ترسیده","دوستاش","به فکر تو","ترسوندت","میخنده","خوشحاله","سرگرمه","عاشقه موزه","حموم بوده","میرقصه");
$soot = array("گیجه","ناراحته","عصبانیه","خیلی ناراحته","دوست داره","عاشقته","خوابش میاد","سردشه","مریض شده","سرگرمه");
$adaby = array("خوشگل شده","قهر کرده","میخنده","پاندا شده","عاشقته","قهرمان شده","خوشش اومد","ناراحته","دوست داره","سردشه");
$bigli = array("اهنگ میگوشه","سلام میکنه","خدافظی میکنه","خوابش میاد","دلش پرمیزنه","دلش شکسته","به فکر تو","گریه میکنه","دوست داره","عاشقته");
$emoji = array("😃","😄","😁","😁","😂","😎","😋","😍","😞","😠","☹️","😞","🤠","🤡","😜","😛","😋","😬","🤐","👿","😈","🎃","😺","😸","😹","😻");
if($pack == "mohammad" or $pack == "sanaz"){
$fountusernamehight = "440";
}
else
{
$fountusernamehight = "505";
}
$randomemoji = array_rand($emoji);
$othertext = ${$pack};
$gets = mb_strlen("$gettext") * 3;
header('Content-type: image/png');
$jpg_image = imagecreatefrompng("sticker/$type/$pack/0.png");
imagesavealpha($jpg_image, true);
$width = $jpg_image[0];
$hight = $jpg_image[1];
$redpen = ImageColorAllocate($jpg_image, 255, 0, 0); // قرمز
$greenpen = ImageColorAllocate($jpg_image, 0, 153, 0); // سبز
$bluepen = ImageColorAllocate($jpg_image, 0, 0, 255);  // ابی
$blackpen = ImageColorAllocate($jpg_image, 0, 0, 0); // سیاه
$whitepen = ImageColorAllocate($jpg_image, 255, 255, 255); // سفید
$yellowpen = ImageColorAllocate($jpg_image, 255, 255, 0); // زرد
$greypen = ImageColorAllocate($jpg_image, 153, 153, 153); // خاکستری
$silverpen = ImageColorAllocate($jpg_image, 204, 204, 204); // نقره
$navypen = ImageColorAllocate($jpg_image, 0, 0, 153); // بنفش
$maroonpen = ImageColorAllocate($jpg_image, 153, 0, 0); // قهوه ای
$gd = new FarsiGD();
$text = $gd->persianText("$gettext $othertext[0]", 'fa', 'normal');
imagettftext($jpg_image, 38, 0, $width + 85 - $gets, $hight + 75, $$repalcecolor, $ANegaarBold, $text);
imagettftext($jpg_image, 15, 0, $width + 1, $hight + $fountusernamehight, $whitepen, $ITCKRIST, "@$usernamebot");
imagepng($jpg_image,"data/{$get}creator.png");
jijibot('createNewStickerSet',[
         'user_id'=>$from_id,
"name"=>"{$get}_by_$usernamebot",
		"title"=>"🤖 سازنده @$usernamebot",
"png_sticker"=>"$web/data/{$get}creator.png",
		"emojis"=>"$emoji[$randomemoji]",
    		]);
if($textmassage == "🎨 سفید" or  $textmassage == "🎨 مشکی"){
$allfiles = scandir("sticker/$type/$pack/");
for($z = 1;$z <= count($allfiles) - 1;$z++){
$jpg_image = imagecreatefrompng("sticker/$type/$pack/$z.png");
imagesavealpha($jpg_image, true);
$gd = new FarsiGD();
$text = $gd->persianText("$gettext $othertext[$z]", 'fa', 'normal');
imagettftext($jpg_image, 38, 0, $width + 85 - $gets, $hight + 75, $$repalcecolor, $ANegaarBold, $text);
imagettftext($jpg_image, 15, 0, $width + 1, $hight + $fountusernamehight, $whitepen, $ITCKRIST, "@$usernamebot");
imagepng($jpg_image,"data/$get$z.png");
$emoji = array("😃","😄","😁","😁","😂","😎","😋","😍","😞","😠","☹️","😞","🤠","🤡","😜","😛","😋","😬","🤐","👿","😈","🎃","😺","😸","😹","😻");
$randomemoji = array_rand($emoji);
jijibot('addStickerToSet',[
         'user_id'=>$from_id,
        "name"=>"{$get}_by_$usernamebot",
		"png_sticker"=>"$web/data/$get$z.png",
		"emojis"=>"$emoji[$randomemoji]",
    		]);
unlink("data/$get$z.png");
}
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"📍 پک استیکر شما با موفقیت ساخته شد 
		
🌟 مشخصات :
📍 نام پک : $packanme
📍 برای اسم : $gettext
📍 رنگ طراحی : $textmassage

🔗 لینک دریافت پک استیکر :
telegram.me/addstickers/{$get}_by_$usernamebot",
    		]);
$jpg_image = imagecreatefrompng("endpack.png");
imagesavealpha($jpg_image, true);
$gd = new FarsiGD();
imagettftext($jpg_image, 40, 0, $width + 93, $hight + 470, $silverpen, $NPIFarnazIranic, "@$usernamebot");
imagepng($jpg_image,"data/{$get}end.png");
jijibot('addStickerToSet',[
         'user_id'=>$from_id,
        "name"=>"{$get}_by_$usernamebot",
"png_sticker"=>"$web/data/{$get}end.png",
		"emojis"=>"$emoji[$randomemoji]",
    		]);	
$cancreatplus = $cancreat - 1 ;
$juser["userfild"]["cancreat"]="$cancreatplus";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
$packlist["$pack"]["$gettext"]["$repalcecolor"]="$get";
$packlist = json_encode($packlist,true);
file_put_contents("data/packlist.json",$packlist);
unlink("data/{$get}creator.png");
unlink("data/{$get}end.png");
}
else
{
if($juser["userfild"]["member"] >= 5){
$allfiles = scandir("sticker/$type/$pack/");
for($z = 1;$z <= count($allfiles) - 1;$z++){
$jpg_image = imagecreatefrompng("sticker/$type/$pack/$z.png");
imagesavealpha($jpg_image, true);
$gd = new FarsiGD();
$text = $gd->persianText("$gettext $othertext[$z]", 'fa', 'normal');
imagettftext($jpg_image, 38, 0, $width + 85 - $gets, $hight + 75, $$repalcecolor, $ANegaarBold, $text);
imagettftext($jpg_image, 15, 0, $width + 1, $hight + $fountusernamehight, $whitepen, $ITCKRIST, "@$usernamebot");
imagepng($jpg_image,"data/$get$z.png");
$emoji = array("😃","😄","😁","😁","😂","😎","😋","😍","😞","😠","☹️","😞","🤠","🤡","😜","😛","😋","😬","🤐","👿","😈","🎃","😺","😸","😹","😻");
$randomemoji = array_rand($emoji);
jijibot('addStickerToSet',[
         'user_id'=>$from_id,
        "name"=>"{$get}_by_$usernamebot",
		"png_sticker"=>"$web/data/$get$z.png",
		"emojis"=>"$emoji[$randomemoji]",
    		]);
unlink("data/$get$z.png");
}
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"📍 پک استیکر شما با موفقیت ساخته شد 
		
🌟 مشخصات :
📍 نام پک : $packanme
📍 برای اسم : $gettext
📍 رنگ طراحی : $textmassage

🔗 لینک دریافت پک استیکر :
telegram.me/addstickers/{$get}_by_$usernamebot",
    		]);
$jpg_image = imagecreatefrompng("endpack.png");
imagesavealpha($jpg_image, true);
$gd = new FarsiGD();
imagettftext($jpg_image, 40, 0, $width + 93, $hight + 470, $silverpen, $NPIFarnazIranic, "@$usernamebot");
imagepng($jpg_image,"data/{$get}end.png");
jijibot('addStickerToSet',[
         'user_id'=>$from_id,
        "name"=>"{$get}_by_$usernamebot",
"png_sticker"=>"$web/data/{$get}end.png",
		"emojis"=>"$emoji[$randomemoji]",
    		]);	
$cancreatplus = $cancreat - 1 ;
$juser["userfild"]["cancreat"]="$cancreatplus";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
$packlist["$pack"]["$gettext"]["$repalcecolor"]="$get";
$packlist = json_encode($packlist,true);
file_put_contents("data/packlist.json",$packlist);
unlink("data/{$get}creator.png");
unlink("data/{$get}end.png");
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🌟 کاربرگرامی برای استفاده از رنگ های به غیر از سیاه و سفید تنها برای کاربران ویژه امکان پذیر است
❄️ کاربران ویژه علاوه بر امکان استفاده از تمام رنگ ها میتوانند از پک های دو اسمی نیز استفاده کنند

📍 برای ویژه کردن حساب خود از دکمه زیر استفاده کنید
📌 در غیر این صورت میتوانید از رنگ های سیاه و سفید استفاده کنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"❄️ حساب ویژه",'callback_data'=>'link']
	],
              ]
        ])
    		]);
}
}
}
else
{
$getpack = $packlist["$pack"]["$gettext"]["$repalcecolor"];
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"🌟 پک استیکر شما در حال ساخت است لطفا منتطر بمانید ...
		
📍 این عملیات ممکن است تا 3 دقیقه طول بکشد",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🤴🏻 استیکر پسرونه"],['text'=>"👸🏻 استیکر دخترونه"]
                ],
												                 [
                ['text'=>"🤵🏻 استیکر دونفره 👰🏻"],['text'=>"😃 استیکر متفرقه"]
                ],
															                 [
                ['text'=>"👤 حساب کاربری"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"📍 پک استیکر شما با موفقیت ساخته شد 
		
🌟 مشخصات :
📍 نام پک : $packanme
📍 برای اسم : $gettext
📍 رنگ طراحی : $textmassage

🔗 لینک دریافت پک استیکر :
telegram.me/addstickers/{$getpack}_by_$usernamebot",
    		]);
$cancreatplus = $cancreat - 1 ;
$juser["userfild"]["cancreat"]="$cancreatplus";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🌟 کاربر گرامی تعداد فرصت های شما به پایان رسیده است

📍 برای افزایش فرصت های ساخت استیکر میتوانید از دکمه زیر استفاده کنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"❄️ افزایش فرصت",'callback_data'=>'link']
	],
              ]
        ])
    		]);
}
}
elseif(in_array($textmassage,array("🎨سفید","🎨مشکی","🎨سبز","🎨ابی","🎨زرد","🎨قرمز","🎨خاکستری","🎨نقره ای","🎨بنفش","🎨قهوه ای"))){
$cancreat = $juser["userfild"]["cancreat"];
if($cancreat > 0){
$type = $juser["userfild"]["type"];
$pack = $juser["userfild"]["pack"];
$boyname = $juser["userfild"]["boyname"];
$girlname = $juser["userfild"]["girlname"];
$packanme = $juser["userfild"]["packname"];
$repalcecolor = str_replace(["🎨سفید","🎨مشکی","🎨سبز","🎨ابی","🎨زرد","🎨قرمز","🎨خاکستری","🎨نقره ای","🎨بنفش","🎨قهوه ای"],["whitepen","blackpen","greenpen","bluepen","greypen","redpen","greypen","silverpen","navypen","maroonpen"],$textmassage);
if($packlist["$pack"]["$boyname"]["$repalcecolor"] != true or $packlist["$pack"]["$girlname"]["$repalcecolor"] != true){
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"🌟 پک استیکر شما در حال ساخت است لطفا منتطر بمانید ...
		
📍 این عملیات ممکن است تا 3 دقیقه طول بکشد",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🤴🏻 استیکر پسرونه"],['text'=>"👸🏻 استیکر دخترونه"]
                ],
												                 [
                ['text'=>"🤵🏻 استیکر دونفره 👰🏻"],['text'=>"😃 استیکر متفرقه"]
                ],
															                 [
                ['text'=>"👤 حساب کاربری"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$ITCKRIST = "font/ITCKRIST.TTF";
$ANegaarBold = "font/ANegaarBold.ttf";
$NPIFarnazIranic = "font/NPIFarnazIranic.ttf";
$get = RandomString();
$mery = array("$girlname رو پای $boyname","بیا بغل $boyname","$girlname $boyname رو بوس","$boyname بخنده","$boyname $girlname رو بوس","بیا بغل $boyname","بیا رو کول $boyname","بیا رو پاهای $boyname","$girlname تو فکر $boyname","$boyname و $girlname بغلهم");
$love = array("$girlname گردن $boyname دوس","قول بده به $girlname","بیا بغل $boyname","$girlname بغل $boyname","$boyname و $girlname عاشقهمن","بیا بغل $boyname","$boyname نرو از پیش $girlname","بیا رو کول $boyname","$girlname $boyname رو بوس","$girlname $boyname رو ناز میکنه");
$story = array("$boyname شجاع شد","با $boyname بیا","$boyname و $girlname شکمو","$boyname فدات شه","$boyname و $girlname ورزشکارن","$boyname و $girlname به فکرهم","$boyname رو کوله $boyname","بیا بغل $boyname","بیا دنبال $girlname","$girlname $boyname رو میکوشه","$boyname بوس فرستاد","$boyname آشپزی میکنه");
$emoji = array("😃","😄","😁","😁","😂","😎","😋","😍","😞","😠","☹️","😞","🤠","🤡","😜","😛","😋","😬","🤐","👿","😈","🎃","😺","😸","😹","😻");
$randomemoji = array_rand($emoji);
$othertext = ${$pack};
$gets = mb_strlen("$boyname") * 3 + mb_strlen("$girlname") * 3;
header('Content-type: image/png');
$jpg_image = imagecreatefrompng("sticker/$type/$pack/0.png");
imagesavealpha($jpg_image, true);
$width = $jpg_image[0];
$hight = $jpg_image[1];
$redpen = ImageColorAllocate($jpg_image, 255, 0, 0); // قرمز
$greenpen = ImageColorAllocate($jpg_image, 0, 153, 0); // سبز
$bluepen = ImageColorAllocate($jpg_image, 0, 0, 255);  // ابی
$blackpen = ImageColorAllocate($jpg_image, 0, 0, 0); // سیاه
$whitepen = ImageColorAllocate($jpg_image, 255, 255, 255); // سفید
$yellowpen = ImageColorAllocate($jpg_image, 255, 255, 0); // زرد
$greypen = ImageColorAllocate($jpg_image, 153, 153, 153); // خاکستری
$silverpen = ImageColorAllocate($jpg_image, 204, 204, 204); // نقره
$navypen = ImageColorAllocate($jpg_image, 0, 0, 153); // بنفش
$maroonpen = ImageColorAllocate($jpg_image, 153, 0, 0); // قهوه ای
$gd = new FarsiGD();
$text = $gd->persianText("$othertext[0]", 'fa', 'normal');
imagettftext($jpg_image, 38, 0, $width + 85 - $gets, $hight + 75, $$repalcecolor, $ANegaarBold, $text);
imagettftext($jpg_image, 15, 0, $width + 1, $hight + 505, $whitepen, $ITCKRIST, "@$usernamebot");
imagepng($jpg_image,"data/{$get}creator.png");
jijibot('createNewStickerSet',[
         'user_id'=>$from_id,
"name"=>"{$get}_by_$usernamebot",
		"title"=>"🤖 سازنده @$usernamebot",
"png_sticker"=>"$web/data/{$get}creator.png",
		"emojis"=>"$emoji[$randomemoji]",
    		]);
$allfiles = scandir("sticker/$type/$pack/");
for($z = 1;$z <= count($allfiles) - 1;$z++){
$jpg_image = imagecreatefrompng("sticker/$type/$pack/$z.png");
imagesavealpha($jpg_image, true);
$gd = new FarsiGD();
$text = $gd->persianText("$othertext[$z]", 'fa', 'normal');
imagettftext($jpg_image, 38, 0, $width + 85 - $gets, $hight + 75, $$repalcecolor, $ANegaarBold, $text);
imagettftext($jpg_image, 15, 0, $width + 1, $hight + 505, $whitepen, $ITCKRIST, "@$usernamebot");
imagepng($jpg_image,"data/$get$z.png");
$emoji = array("😃","😄","😁","😁","😂","😎","😋","😍","😞","😠","☹️","😞","🤠","🤡","😜","😛","😋","😬","🤐","👿","😈","🎃","😺","😸","😹","😻");
$randomemoji = array_rand($emoji);
jijibot('addStickerToSet',[
         'user_id'=>$from_id,
        "name"=>"{$get}_by_$usernamebot",
		"png_sticker"=>"$web/data/$get$z.png",
		"emojis"=>"$emoji[$randomemoji]",
    		]);
unlink("data/$get$z.png");
}
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"📍 پک استیکر شما با موفقیت ساخته شد 
		
🌟 مشخصات :
📍 نام پک : $packanme
📍 برای اسم : $boyname و $girlname
📍 رنگ طراحی : $textmassage

🔗 لینک دریافت پک استیکر :
telegram.me/addstickers/{$get}_by_$usernamebot",
    		]);
$jpg_image = imagecreatefrompng("endpack.png");
imagesavealpha($jpg_image, true);
$gd = new FarsiGD();
imagettftext($jpg_image, 40, 0, $width + 93, $hight + 470, $silverpen, $NPIFarnazIranic, "@$usernamebot");
imagepng($jpg_image,"data/{$get}end.png");
jijibot('addStickerToSet',[
         'user_id'=>$from_id,
        "name"=>"{$get}_by_$usernamebot",
"png_sticker"=>"$web/data/{$get}end.png",
		"emojis"=>"$emoji[$randomemoji]",
    		]);	
$cancreatplus = $cancreat - 1 ;
$juser["userfild"]["cancreat"]="$cancreatplus";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
$packlist["$pack"]["$boyname"]["$repalcecolor"]="$get";
$packlist["$pack"]["$girlname"]["$repalcecolor"]="$get";
$packlist = json_encode($packlist,true);
file_put_contents("data/packlist.json",$packlist);
unlink("data/{$get}creator.png");
unlink("data/{$get}end.png");
}
else
{
$getpack = $packlist["$pack"]["$boyname"]["$repalcecolor"];
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"🌟 پک استیکر شما در حال ساخت است لطفا منتطر بمانید ...
		
📍 این عملیات ممکن است تا 3 دقیقه طول بکشد",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🤴🏻 استیکر پسرونه"],['text'=>"👸🏻 استیکر دخترونه"]
                ],
												                 [
                ['text'=>"🤵🏻 استیکر دونفره 👰🏻"],['text'=>"😃 استیکر متفرقه"]
                ],
															                 [
                ['text'=>"👤 حساب کاربری"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"📍 پک استیکر شما با موفقیت ساخته شد 
		
🌟 مشخصات :
📍 نام پک : $packanme
📍 برای اسم : $boyname و $girlname
📍 رنگ طراحی : $textmassage

🔗 لینک دریافت پک استیکر :
telegram.me/addstickers/{$getpack}_by_$usernamebot",
    		]);
$cancreatplus = $cancreat - 1 ;
$juser["userfild"]["cancreat"]="$cancreatplus";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🌟 کاربر گرامی تعداد فرصت های شما به پایان رسیده است

📍 برای افزایش فرصت های ساخت استیکر میتوانید از دکمه زیر استفاده کنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"❄️ افزایش فرصت",'callback_data'=>'link']
	],
              ]
        ])
    		]);
}
}
elseif($data=="nextgb"){
$get = $cuser["userfild"]["get"];
$name = array("عشق","عشق دو","مری و ونتور");
$getfolder = array("love","story","mery");
$number = array("10","12","10");
$count = count($getfolder);
$getplus = $get + 1 ;
$getpluss = $get + 2 ;
if($getpluss < $count){
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $getpluss از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'selectvip']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downgb'],['text'=>"⏭ بعدی",'callback_data'=>'nextgb']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $getpluss از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'selectvip']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downgb']
	],
              ]
        ])
    		]);
$cuser["userfild"]["get"]="$getplus";
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
}
elseif($data == "downgb"){
$get = $cuser["userfild"]["get"];
$name = array("عشق","عشق دو","مری و ونتور");
$getfolder = array("love","story","mery");
$number = array("10","12","10");
$count = count($getfolder);
$getplus = $get - 1 ;
$getpluss = $get + 1 ;
if($getplus > 0){
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $get از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'selectvip']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downgb'],['text'=>"⏭ بعدی",'callback_data'=>'nextgb']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $get از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'selectvip']
	],
			[
	['text'=>"⏭ بعدی",'callback_data'=>'nextgb']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
}
elseif($data=="nextother"){
$get = $cuser["userfild"]["get"];
$name = array("مینیون ها","خرگوش","کوچولو","بیگلی و میگلی","سوت");
$getfolder = array("menion","rani","adaby","bigli","soot");
$number = array("14","11","10","10","10");
$count = count($getfolder);
$getplus = $get + 1 ;
$getpluss = $get + 2 ;
if($getpluss < $count){
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $getpluss از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downother'],['text'=>"⏭ بعدی",'callback_data'=>'nextother']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $getpluss از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downother']
	],
              ]
        ])
    		]);
$cuser["userfild"]["get"]="$getplus";
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
}
elseif($data == "downother"){
$get = $cuser["userfild"]["get"];
$name = array("مینیون ها","خرگوش","کوچولو","بیگلی و میگلی","سوت");
$getfolder = array("menion","rani","adaby","bigli","soot");
$number = array("14","11","10","10","10");
$count = count($getfolder);
$getplus = $get - 1 ;
$getpluss = $get + 1 ;
if($getplus > 0){
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $get از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downother'],['text'=>"⏭ بعدی",'callback_data'=>'nextother']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $get از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"⏭ بعدی",'callback_data'=>'nextother']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
}
elseif($data=="nextgirl"){
$get = $cuser["userfild"]["get"];
$name = array("دختر عاشق","خرگوش خانوم","مهسا","السا و انا","انگس");
$getfolder = array("sanaz","zoot","mahsa","elsa","anges");
$number = array("19","14","12","10","11");
$count = count($getfolder);
$getplus = $get + 1 ;
$getpluss = $get + 2 ;
if($getpluss < $count){
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $getpluss از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downgirl'],['text'=>"⏭ بعدی",'callback_data'=>'nextgirl']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $getpluss از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downgirl']
	],
              ]
        ])
    		]);
$cuser["userfild"]["get"]="$getplus";
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
}
elseif($data == "downgirl"){
$get = $cuser["userfild"]["get"];
$name = array("دختر عاشق","خرگوش خانوم","مهسا","السا و انا","انگس");
$getfolder = array("sanaz","zoot","mahsa","elsa","anges");
$number = array("19","14","12","10","11");
$count = count($getfolder);
$getplus = $get - 1 ;
$getpluss = $get + 1 ;
if($getplus > 0){
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $get از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downgirl'],['text'=>"⏭ بعدی",'callback_data'=>'nextgirl']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $get از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"⏭ بعدی",'callback_data'=>'nextgirl']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
}
elseif($data=="nextboy"){
$get = $cuser["userfild"]["get"];
$name = array("پسر عاشق","باب اسفنجی","اسکار","سیمون","مرد کوچولو");
$getfolder = array("mohammad","bob","oscar","simon","boss");
$number = array("15","10","10","13","10");
$count = count($getfolder);
$getplus = $get + 1 ;
$getpluss = $get + 2 ;
if($getpluss < $count){
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $getpluss از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downboy'],['text'=>"⏭ بعدی",'callback_data'=>'nextboy']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $getpluss از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downboy']
	],
              ]
        ])
    		]);
$cuser["userfild"]["get"]="$getplus";
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
}
elseif($data == "downboy"){
$get = $cuser["userfild"]["get"];
$name = array("پسر عاشق","باب اسفنجی","اسکار","سیمون","مرد کوچولو");
$getfolder = array("mohammad","bob","oscar","simon","boss");
$number = array("15","10","10","13","10");
$count = count($getfolder);
$getplus = $get - 1 ;
$getpluss = $get + 1 ;
if($getplus > 0){
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $get از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"قبلی ⏮",'callback_data'=>'downboy'],['text'=>"⏭ بعدی",'callback_data'=>'nextboy']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🌟 نام پک : $name[$getplus]
📍 تعداد استیکر : $number[$getplus] عدد
🎈 شماره پک : $get از $count
[‌‌]($web/replica/$getfolder[$getplus].jpg)",
		 'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ انتخاب",'callback_data'=>'select']
	],
			[
	['text'=>"⏭ بعدی",'callback_data'=>'nextboy']
	],
              ]
        ])
    		]);
$cuser["userfild"]["pack"]="$getfolder[$getplus]";
$cuser["userfild"]["packname"]="$name[$getplus]";
$cuser["userfild"]["get"]="$getplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
}
elseif($data=="select"){
$packname = $cuser["userfild"]["packname"];
$cancreat = $cuser["userfild"]["cancreat"];
if($cancreat > 0){
jijibot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🌟 شما پیکج $packname رو انتخاب کردید

📍 لطفا نام کی میخواهید برای استیکر استفاده شود را وارد کنید
⚠️ حداقل نام وارد شده باید 2 حرف و حداکثر 10 حرف باشد
📌 نام باید شمال حروف فارسی باشد بدون ایموجی ... ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$cuser["userfild"]["step"]="settext";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🌟 کاربر گرامی تعداد فرصت های شما به پایان رسیده است

📍 برای افزایش فرصت های ساخت استیکر میتوانید از دکمه زیر استفاده کنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"❄️ افزایش فرصت",'callback_data'=>'link']
	],
              ]
        ])
    		]);
}
}
elseif($data=="selectvip"){
$packname = $cuser["userfild"]["packname"];
$cancreat = $cuser["userfild"]["cancreat"];
$member = $cuser["userfild"]["member"];
if($cancreat > 0){
if($member >= 5){
jijibot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🌟 شما پیکج $packname رو انتخاب کردید

📍 لطفا نام اول [دختر] را وارد کنید
⚠️ حداقل نام وارد شده باید 2 حرف و حداکثر 10 حرف باشد
📌 نام باید شمال حروف فارسی باشد بدون ایموجی ... ",
'reply_markup'=>json_encode([
            	'keyboard'=>[
      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$cuser["userfild"]["step"]="setgirlname";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🌟 کاربر گرامی استفاده از پک های دو اسم تنها برای کابران ویژه امکان پذیر است

📍 برای ویژه کردن حساب خود میتوانید از دکمه زیر استفاده کنید
📌 در حساب ویژه علاوه بر امکان استفاده از پک های دو اسمی میتوانید از رنگ های متن مختلف نیز استفاده کنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"❄️ حساب ویژه",'callback_data'=>'link']
	],
              ]
        ])
    		]);
}
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🌟 کاربر گرامی تعداد فرصت های شما به پایان رسیده است

📍 برای افزایش فرصت های ساخت استیکر میتوانید از دکمه زیر استفاده کنید",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"❄️ افزایش فرصت",'callback_data'=>'link']
	],
              ]
        ])
    		]);
}
}
elseif($data=="link"){
$member = $cuser["userfild"]["member"];
$cancreat = $cuser["userfild"]["cancreat"];
jijibot('sendphoto',[
	'chat_id'=>$chatid,
	'photo'=>"$web/replica/logo.jpg",
	'caption'=>"این ربات کلی استیکر مخصوص اسم خودت برات میسازه 👌

🌟 کلی استیکر دخترونه پسرونه و دو نفره

همین الان وارد شو و استیکر اسم خودت رو بساز 👇

telegram.me/$usernamebot/?start=$fromid",
    		]);
	jijibot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🎈 پیام بالا حاوی لینک دعوت شما به ربات است 	
🌟 با دعوت هر نفر یک فرصت ساخت استیکر دریافت کنید و زمانی که تعداد زیر مجموعه های شما به 5 نفر رسید میتوانید از تمام رنگ ها استفاده کنید

👥 تعداد زیر مجموعه ها : $member
🌟تعداد فرصت ساخت استیکر : $cancreat",
	  	]);
}
elseif($data=="join"){
$forchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@".$channel."&user_id=".$fromid));
$tch = $forchannel->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){	
jijibot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"📍 عضویت شما تایید شد
	
🌟 اکنون میتوانید از دکمه های زیر استفاده کنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🤴🏻 استیکر پسرونه"],['text'=>"👸🏻 استیکر دخترونه"]
                ],
												                 [
                ['text'=>"🤵🏻 استیکر دونفره 👰🏻"],['text'=>"😃 استیکر متفرقه"]
                ],
															                 [
                ['text'=>"👤 حساب کاربری"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
else
{
      jijibot('answercallbackquery', [
            'callback_query_id' =>$membercall,
            'text' => "❌ هنوز داخل کانال @$channel عضو نیستید",
            'show_alert' =>true
        ]);
}
}
elseif($juser["userfild"]["step"] == "setgirlname" ){
if(preg_match("/^[\x{0600}-\x{06FF}' ]*$/u", $textmassage)){
$gets = mb_strlen("$textmassage");
if($gets > 2 && $gets < 10){
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"📍 نام دختر وارد شد : $textmassage
		
🌟 اکنون نام دوم [پسر] را وارد کنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$juser["userfild"]["girlname"]="$textmassage";
$juser["userfild"]["step"]="setboyname";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 خطا در نام وارد شده
	
📌 نام شما باید بین 2 تا 10 کاراکتر باشد",
'reply_markup'=>json_encode([
            	'keyboard'=>[
      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 خطا در نام وارد شده
	
📌 نام وارد شده باید فارسی باشد از وارد کردن حروف لاتین یا اعداد خودداری کنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
elseif($juser["userfild"]["step"] == "setboyname" ){
if(preg_match("/^[\x{0600}-\x{06FF}' ]*$/u", $textmassage)){
$gets = mb_strlen("$textmassage");
if($gets > 2 && $gets < 10){
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"📍 نام پسر وارد شد: $textmassage
		
🎨 رنگ مورد نظر متن را انتخاب کنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				     [
                ['text'=>"🎨سفید"],['text'=>"🎨مشکی"]
                ],
				     [
                ['text'=>"🎨سبز"],['text'=>"🎨ابی"],['text'=>"🎨زرد"]
                ],
							     [
                ['text'=>"🎨قرمز"],['text'=>"🎨خاکستری"],['text'=>"🎨نقره ای"]
                ],
					     [
                ['text'=>"🎨بنفش"],['text'=>"🎨قهوه ای"]
                ],
				      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$juser["userfild"]["boyname"]="$textmassage";
$juser["userfild"]["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 خطا در نام وارد شده
	
📌 نام شما باید بین 2 تا 10 کاراکتر باشد",
'reply_markup'=>json_encode([
            	'keyboard'=>[
      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 خطا در نام وارد شده
	
📌 نام وارد شده باید فارسی باشد از وارد کردن حروف لاتین یا اعداد خودداری کنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
elseif($juser["userfild"]["step"] == "settext" ){
if(preg_match("/^[\x{0600}-\x{06FF}' ]*$/u", $textmassage)){
$gets = mb_strlen("$textmassage");
if($gets > 2 && $gets < 10){
jijibot('sendmessage',[
                'chat_id'=>$chat_id,
        "text"=>"📍 نام انتخابی شما برای ساخت استیکر : $textmassage
		
🎨 رنگ مورد نظر متن را انتخاب کنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
				     [
                ['text'=>"🎨 سفید"],['text'=>"🎨 مشکی"]
                ],
				     [
                ['text'=>"🎨 سبز"],['text'=>"🎨 ابی"],['text'=>"🎨 زرد"]
                ],
							     [
                ['text'=>"🎨 قرمز"],['text'=>"🎨 خاکستری"],['text'=>"🎨 نقره ای"]
                ],
					     [
                ['text'=>"🎨 بنفش"],['text'=>"🎨 قهوه ای"]
                ],
				      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$juser["userfild"]["name"]="$textmassage";
$juser["userfild"]["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 خطا در نام وارد شده
	
📌 نام شما باید بین 2 تا 10 کاراکتر باشد",
'reply_markup'=>json_encode([
            	'keyboard'=>[
      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
else
{
jijibot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📍 خطا در نام وارد شده
	
📌 نام وارد شده باید فارسی باشد از وارد کردن حروف لاتین یا اعداد خودداری کنید",
'reply_markup'=>json_encode([
            	'keyboard'=>[
      [
                ['text'=>"🔙 برگشت"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
}
//==============================================================
/*
─═ঊঈঊঈ═─╮ 
کانال رباتسازی آیرو_بوتساز 
انواع سورس 
رایگان و دیباگ 
ادرس کانال 
https://t.me/IRO_BOTSAZ
─═ঊঈঊঈ═─╯
*/
//panel admin
elseif($textmassage=="/panel" or $textmassage=="panel" or $textmassage=="مدیریت"){
if ($tc == "private") {
if (in_array($from_id,$Dev)){
jijibot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🚦 ادمین عزیز به پنل مدریت ربات خوش امدید",
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"📍 امار ربات"],['text'=>"📍 ویژه کردن"]               
		 ],
 	[
	  	['text'=>"📍 ارسال به همه"],['text'=>"📍 فروارد همگانی"]
	  ],
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
}
}
elseif($textmassage=="برگشت 🔙"){
if ($tc == "private") {
if (in_array($from_id,$Dev)){
jijibot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🚦 به منوی مدیریت بازگشتید",
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"📍 امار ربات"],['text'=>"📍 ویژه کردن"]               
		 ],
 	[
	  	['text'=>"📍 ارسال به همه"],['text'=>"📍 فروارد همگانی"]
	  ],
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["fileget"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
}
elseif($textmassage=="📍 امار ربات"){
if (in_array($from_id,$Dev)){
$files1 = scandir("data/");
$all = count($files1);
				jijibot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"🤖 امار ربات شما : 
		
📌 تعداد عضو ها : $all",
                'hide_keyboard'=>true,
		]);
		}
}
elseif ($textmassage == '📍 ویژه کردن' ) {
if (in_array($from_id,$Dev)){
         jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"لطفا ایدی کاربر را ارسال کنید 🚀",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["fileget"]="senduse";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif ($juser["userfild"]["fileget"] == 'senduse') {
if ($textmassage != "برگشت 🔙") {
$id = $juser["userfild"]["idsend"];
$inuser = json_decode(file_get_contents("data/$textmassage.json"),true);
$coin = $inuser["userfild"]["cancreat"];
$member = $inuser["userfild"]["member"];
$coinplus = $coin + 30;
$memberplus = $member + 5;
         jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"فرد با موفقیت ویژه شد ✅
			
📍 تعداد 30 فرصت نیز برای کابر ارسال شد
📍 ایدی فرد : $textmassage",
 ]);
$inuser["userfild"]["cancreat"]="$coinplus";
$inuser["userfild"]["member"]="$memberplus";
$inuser = json_encode($inuser,true);
file_put_contents("data/$textmassage.json",$inuser);
}
}
elseif ($textmassage == '📍 ارسال به همه' ) {
if (in_array($from_id,$Dev)){
         jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"لطفا متن خود را ارسال کنید 🚀",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["file"]="sendtoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif ($juser["userfild"]["file"] == 'sendtoall') {
$juser["userfild"]["file"]="none";
$numbers = $user["userlist"];
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
if ($textmassage != "برگشت 🔙") {
         jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"پیام با موفقیت ارسال شد ✔️",
	  'reply_to_message_id'=>$message_id,
 ]);
for($z = 0;$z <= count($numbers)-1;$z++){
     jijibot('sendmessage',[
          'chat_id'=>$numbers[$z],        
		  'text'=>"$text",
        ]);
}
}
}
elseif ($textmassage == '📍 فروارد همگانی' ) {
if (in_array($from_id,$Dev)){
         jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"لطفا متن خود را فوروارد کنید  🚀",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["file"]="fortoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif ($juser["userfild"]["file"] == 'fortoall') {
$juser["userfild"]["file"]="none";
$numbers = $user["userlist"];
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
if ($textmassage != "برگشت 🔙") {
         jijibot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"پیام با موفقیت ارسال شد ✔️",
	  'reply_to_message_id'=>$message_id,
 ]);
for($z = 0;$z <= count($numbers)-1;$z++){
Forward($numbers[$z], $chat_id,$message_id);
}
}
}

/*
─═ঊঈঊঈ═─╮ 
کانال رباتسازی آیرو_بوتساز 
انواع سورس 
رایگان و دیباگ 
ادرس کانال 
https://t.me/IRO_BOTSAZ
─═ঊঈঊঈ═─╯
*/
?>
